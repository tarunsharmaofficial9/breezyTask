﻿let getLocationAPIUrl = 'https://maps.googleapis.com/maps/api/geocode/json?&address=';

let getTimezoneAPIUrl = 'https://maps.googleapis.com/maps/api/timezone/json?location=';

function getAddressByLocation(locationName) {
debugger
    //I am using google services to get address, timezone and so on.

    //So for google services it need to API key to run and please make sure that you have enabled google geolocation and time zone api

    let apiKey = "*******************";   //Put your api key here 

    //locationName = "paris";

    let url = getLocationAPIUrl + locationName + '&key=' + apiKey;
    $.get(url, function (data, status) {
        if (status === "success" && data.results.length > 0) {
            let address = data.results[0];
            //getTimeZone(apiKey, address.geometry.location.lat, address.geometry.location.lng);
            getWeatherByLatLng(address.geometry.location.lat, address.geometry.location.lng);
        }
        else {
            alert('Given input is not correct.');
        }
    });
}

function getTimeZone(apiKey, lat, lng) {
    let url = getTimezoneAPIUrl + lat + "," + lng + "&timestamp=1374868635&sensor=false&key=" + apiKey;
    $.get(url, function (data, status) {
        if (status === "success") {
            let timezone = "timezone";  //get timezone from returned data
            getCurrentTimeByTimezone(timezone);
            //get timezone here and pass to next method to get time by timezone
        }
        else {
            alert('Invalid location name given.');
        }
    });
}

function getCurrentTimeByTimezone(zone) {
    //it will display time with date
    //console.log(new Date().toLocaleString("en-US", { timeZone: "Europe/Paris" }));
    console.log(new Date().toLocaleString("en-US", { timeZone: zone }));

    //it will display time only
    //console.log(new Date(new Date().toLocaleString("en-US", { timeZone: "Europe/Paris" })).toLocaleTimeString());
    console.log(new Date(new Date().toLocaleString("en-US", { timeZone: zone })).toLocaleTimeString());
}

let inputs = ["Paris", "New York", "10005", "Tokyo", "São Paulo", "Pluto"];

function getCurrentTimeAndWeather() {
    if (inputs.length > 0) {
        for (var i = 0; i < inputs.length; i++) {
            getAddressByLocation(inputs[i]);
        }
    }
}

function getWeatherByLatLng(lat, lng) {

    let apiId = "****************";  //Need apiId to use here.

    var url = "api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + lng + "&appid=" + apiId;
    $.get(url, function (data, status) {
        if (status === "success") {
            let weatherData = data;
            console.log(weatherData);
            //now we can use this weather data
        }
        else {
            alert('Invalid location name given.');
        }
    });
}

getCurrentTimeAndWeather();